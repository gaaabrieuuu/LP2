﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PEstoque01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int[,] produto = new int[2,4];
            int[] valores = new int[2];

            int auxII;
            string aux;

            for(int i=0; i<2; i++)
            {
                for(int j=0; j<4; j++)
                {
                    aux = Interaction.InputBox($"Insira o total de vendas" +
                        $" do produto {i+1} na semana {j+1}", "Entrada de Dados");
                    if(aux == "")
                    {
                        MessageBox.Show("Informe um valor!");
                        j--;
                    }
                    else if(!Int32.TryParse(aux, out auxII))
                    {
                        MessageBox.Show("Informe um número inteiro!");
                    }
                    else
                    {
                        lstboxResumoProd.Items.Add($"Total Entradas do Produto {i+1} Semana {j + 1} - {aux}\n");
                        valores[i] += auxII;
                    }
                }
                lstboxResumoProd.Items.Add($">> Total Entradas do Produto {i + 1}: {valores[i]}\n");
                lstboxResumoProd.Items.Add($"----------------------------");
            }
            lstboxResumoProd.Items.Add($">> Total Geral Entradas: {valores[0] + valores[1]}\n");

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstboxResumoProd.Items.Clear();
        }
    }
}
