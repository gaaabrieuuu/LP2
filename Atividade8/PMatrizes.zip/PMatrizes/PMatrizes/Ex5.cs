﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Ex5 : Form
    {
        public Ex5()
        {
            InitializeComponent();
        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            ArrayList gabarito = new ArrayList() { "A", "B", "C", "D",
            "A", "B", "C", "D", "A", "B"};
            string[,] respostas = new string[2,10];
            string[] nomes = new string[2];
            string aux = "";

            for (int i = 0; i < nomes.Length; i++)
            {
                aux = Interaction.InputBox($"Digite o {i + 1}º nome",
                    "Entrada de Dados");
                if (aux == "")
                {
                    MessageBox.Show("Insira um valor válido!");
                    i--;
                }
                else
                {
                    nomes[i] = aux;
                    for(int j = 0; j < 11; j++)
                    {
                        aux = Interaction.InputBox($"Digite a {i + 1}º resposta",
                            "Entrada de Dados").ToUpper();
                        if(aux != "A" || aux != "B" || aux != "C" || aux != "D" || aux != "E")
                        {
                            MessageBox.Show("Insira um valor válido!");
                            j--;
                        }
                        else
                        {
                            respostas[i, j] = aux;
                        }   
                    }
                }
            }

            for (int i = 0; i < nomes.Length; i++)
            {
                for(int j = 0; j<11; j++)
                {
                    if(respostas[i, j] == gabarito[j])
                    {
                        lboxNomes.Items.Add($"O aluno {nomes[i]} acertou a questão {j}. Resposta {gabarito[j]}. Marcou {respostas[i, j]}");
                    }
                    else
                    {
                        lboxNomes.Items.Add($"O aluno {nomes[i]} errou a questão {j}. Resposta {gabarito[j]}. Marcou {respostas[i,j]}");
                    }
                }
            }
        }
    }
}
