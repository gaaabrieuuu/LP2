﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vector = new int[20];
            string aux = "";

            for (int i=0; i<20; i++)
            {
                aux = Interaction.InputBox($"Digite o {i + 1}º número",
                    "Entrada de Dados");
                if (!int.TryParse(aux, out vector[i]))
                {
                    MessageBox.Show("Valor Inválido!");
                    i--;
                }

                Array.Reverse(vector);
                aux = " ";
                aux = string.Join("\n", vector);
                MessageBox.Show(aux);
            }
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList() { "Ana", "Andre",
                "Beatriz", "Camila", "Joao", "Joana", "Otavio", "Marcelo", "Pedro", "Thais" };

            lista.Remove("Otavio");

            String auxiliar = "";

            foreach (String nome in lista)
            {
                auxiliar += nome + "\n";
            }

            MessageBox.Show(auxiliar);
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            Double[,] Notas = new Double[20, 3];
            String auxiliar = "";
            Double media = 0;
            String saida = "";

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}", "Entrada de Dados");
                    if (!Double.TryParse(auxiliar, out Notas[i, j]) || Notas[i, j] < 0 || Notas[i, j] > 10)
                    {
                        MessageBox.Show("Dado Inválido");
                    }
                    else
                    {
                        media += Notas[i, j];
                    }
                }
                saida += $"Aluno: {i + 1}: media {media / 3}";
                media = 0;
                MessageBox.Show(saida);
            }
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            if(Application.OpenForms.OfType<Ex4>().Count() > 0)
            {
                Application.OpenForms["Ex4"].BringToFront();
            }
            else
            {
                Ex4 ex4 = new Ex4();
                ex4.Show();
            }
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Ex5>().Count() > 0)
            {
                Application.OpenForms["Ex5"].BringToFront();
            }
            else
            {
                Ex5 ex5 = new Ex5();
                ex5.Show();
            }
        }
    }
}
