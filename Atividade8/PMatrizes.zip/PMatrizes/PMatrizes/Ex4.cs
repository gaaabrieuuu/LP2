﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Ex4 : Form
    {
        public Ex4()
        {
            InitializeComponent();
        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            int[] tamanho = new int[10];
            string aux = "";

            for (int i = 0; i < nomes.Length; i++)
            {
                aux = Interaction.InputBox($"Digite o {i + 1}º nome",
                    "Entrada de Dados");
                if (aux == "")
                {
                    MessageBox.Show("Insira um valor válido!");
                    i--;
                }else
                {
                    nomes[i] = aux;
                    tamanho[i] = nomes[i].Replace(" ", "").Length;
                }
            }

            for (int i = 0; i < tamanho.Length; i++)
            {
                lboxNomes.Items.Add($"O nome {nomes[i]} tem {tamanho[i]} caracteres!\n");
            }
        }
    }
}
