﻿namespace PImc
{
    partial class FormIMC
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            txtPesoAtual = new MaskedTextBox();
            lblPesoAtual = new Label();
            lblAltura = new Label();
            txtAltura = new MaskedTextBox();
            lblIMC = new Label();
            txtIMC = new MaskedTextBox();
            btnCalcular = new Button();
            btnLimpar = new Button();
            btnSair = new Button();
            errorPesoAtual = new ErrorProvider(components);
            lblResultado = new Label();
            errorAltura = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)errorPesoAtual).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorAltura).BeginInit();
            SuspendLayout();
            // 
            // txtPesoAtual
            // 
            txtPesoAtual.Location = new Point(171, 39);
            txtPesoAtual.Mask = "999.00";
            txtPesoAtual.Name = "txtPesoAtual";
            txtPesoAtual.Size = new Size(150, 31);
            txtPesoAtual.TabIndex = 0;
            txtPesoAtual.Validated += txtPesoAtual_Validated;
            // 
            // lblPesoAtual
            // 
            lblPesoAtual.AutoSize = true;
            lblPesoAtual.Location = new Point(69, 42);
            lblPesoAtual.Name = "lblPesoAtual";
            lblPesoAtual.Size = new Size(96, 25);
            lblPesoAtual.TabIndex = 1;
            lblPesoAtual.Text = "Peso atual:";
            // 
            // lblAltura
            // 
            lblAltura.AutoSize = true;
            lblAltura.Location = new Point(102, 89);
            lblAltura.Name = "lblAltura";
            lblAltura.Size = new Size(63, 25);
            lblAltura.TabIndex = 3;
            lblAltura.Text = "Altura:";
            // 
            // txtAltura
            // 
            txtAltura.Location = new Point(171, 86);
            txtAltura.Mask = "9.00";
            txtAltura.Name = "txtAltura";
            txtAltura.Size = new Size(150, 31);
            txtAltura.TabIndex = 2;
            txtAltura.Validated += txtAltura_Validated;
            // 
            // lblIMC
            // 
            lblIMC.AutoSize = true;
            lblIMC.Location = new Point(117, 135);
            lblIMC.Name = "lblIMC";
            lblIMC.Size = new Size(48, 25);
            lblIMC.TabIndex = 5;
            lblIMC.Text = "IMC:";
            // 
            // txtIMC
            // 
            txtIMC.Enabled = false;
            txtIMC.Location = new Point(171, 132);
            txtIMC.Name = "txtIMC";
            txtIMC.Size = new Size(150, 31);
            txtIMC.TabIndex = 4;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(32, 198);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(112, 34);
            btnCalcular.TabIndex = 6;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(150, 198);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(112, 34);
            btnLimpar.TabIndex = 7;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(268, 198);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(112, 34);
            btnSair.TabIndex = 8;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // errorPesoAtual
            // 
            errorPesoAtual.ContainerControl = this;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(32, 170);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(59, 25);
            lblResultado.TabIndex = 9;
            lblResultado.Text = "label1";
            lblResultado.Visible = false;
            // 
            // errorAltura
            // 
            errorAltura.ContainerControl = this;
            // 
            // FormIMC
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(415, 270);
            Controls.Add(lblResultado);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(btnCalcular);
            Controls.Add(lblIMC);
            Controls.Add(txtIMC);
            Controls.Add(lblAltura);
            Controls.Add(txtAltura);
            Controls.Add(lblPesoAtual);
            Controls.Add(txtPesoAtual);
            Name = "FormIMC";
            Text = "Calculadora de IMC";
            ((System.ComponentModel.ISupportInitialize)errorPesoAtual).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorAltura).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MaskedTextBox txtPesoAtual;
        private Label lblPesoAtual;
        private Label lblAltura;
        private MaskedTextBox txtAltura;
        private Label lblIMC;
        private MaskedTextBox txtIMC;
        private Button btnCalcular;
        private Button btnLimpar;
        private Button btnSair;
        private ErrorProvider errorPesoAtual;
        private Label lblResultado;
        private ErrorProvider errorAltura;
    }
}
