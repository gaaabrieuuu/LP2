namespace PImc
{
    public partial class FormIMC : Form
    {
        double pesoAtual, altura, imc;
        public FormIMC()
        {
            InitializeComponent();
        }

        private void txtPesoAtual_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtPesoAtual.Text, out pesoAtual) || pesoAtual <= 0)
            {
                errorPesoAtual.SetError(txtPesoAtual, "O campo Peso Atual n�o" +
                    " pode estar vazio");
                txtPesoAtual.Focus();
            }
            else
            {
                errorPesoAtual.Clear();
            }
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out altura) || altura <= 0)
            {
                errorAltura.SetError(txtAltura, "O campo Altura n�o" +
                    " pode estar vazio");
                txtAltura.Focus();
            }
            else
            {
                errorAltura.Clear();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = pesoAtual / (altura * altura);

            imc = Math.Round(imc, 1);

            txtIMC.Text = imc.ToString();

            lblResultado.Visible = true;

            switch (imc)
            {
                case < 18.5:
                    lblResultado.Text = "Classifica��o: Magreza";
                    break;
                case < 25:
                    lblResultado.Text = "Classifica��o: Normal";
                    break;
                case < 30:
                    lblResultado.Text = "Classifica��o: Sobrepeso";
                    break;
                case < 40:
                    lblResultado.Text = "Classifica��o: Obesidade";
                    break;
                case > 40:
                    lblResultado.Text = "Classifica��o: Obesidade Grave";
                    break;

            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtIMC.Clear();
            txtAltura.Clear();
            txtPesoAtual.Clear();
            lblResultado.Visible = false;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
