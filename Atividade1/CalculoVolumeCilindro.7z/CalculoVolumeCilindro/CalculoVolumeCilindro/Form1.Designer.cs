﻿namespace CalculoVolumeCilindro
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblRaio = new Label();
            txtRaio = new TextBox();
            txtAltura = new TextBox();
            lblAltura = new Label();
            txtVolume = new TextBox();
            lblVolume = new Label();
            btnCalcular = new Button();
            btnLimpar = new Button();
            btnFechar = new Button();
            SuspendLayout();
            // 
            // lblRaio
            // 
            lblRaio.AutoSize = true;
            lblRaio.Font = new Font("Segoe UI", 12F);
            lblRaio.Location = new Point(109, 48);
            lblRaio.Name = "lblRaio";
            lblRaio.Size = new Size(65, 32);
            lblRaio.TabIndex = 0;
            lblRaio.Text = "Raio:";
            // 
            // txtRaio
            // 
            txtRaio.Location = new Point(238, 48);
            txtRaio.Name = "txtRaio";
            txtRaio.Size = new Size(196, 31);
            txtRaio.TabIndex = 1;
            txtRaio.TextChanged += textBox1_TextChanged;
            txtRaio.Validated += txtRaio_Validated;
            // 
            // txtAltura
            // 
            txtAltura.Location = new Point(238, 117);
            txtAltura.Name = "txtAltura";
            txtAltura.Size = new Size(196, 31);
            txtAltura.TabIndex = 3;
            txtAltura.Validated += txtAltura_Validated;
            // 
            // lblAltura
            // 
            lblAltura.AutoSize = true;
            lblAltura.Font = new Font("Segoe UI", 12F);
            lblAltura.Location = new Point(109, 117);
            lblAltura.Name = "lblAltura";
            lblAltura.Size = new Size(82, 32);
            lblAltura.TabIndex = 2;
            lblAltura.Text = "Altura:";
            // 
            // txtVolume
            // 
            txtVolume.Enabled = false;
            txtVolume.Location = new Point(238, 190);
            txtVolume.Name = "txtVolume";
            txtVolume.ReadOnly = true;
            txtVolume.Size = new Size(196, 31);
            txtVolume.TabIndex = 5;
            // 
            // lblVolume
            // 
            lblVolume.AutoSize = true;
            lblVolume.Font = new Font("Segoe UI", 12F);
            lblVolume.Location = new Point(109, 190);
            lblVolume.Name = "lblVolume";
            lblVolume.Size = new Size(100, 32);
            lblVolume.TabIndex = 4;
            lblVolume.Text = "Volume:";
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(62, 347);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(112, 34);
            btnCalcular.TabIndex = 6;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(238, 347);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(112, 34);
            btnLimpar.TabIndex = 7;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnFechar
            // 
            btnFechar.Location = new Point(418, 347);
            btnFechar.Name = "btnFechar";
            btnFechar.Size = new Size(112, 34);
            btnFechar.TabIndex = 8;
            btnFechar.Text = "Fechar";
            btnFechar.UseVisualStyleBackColor = true;
            btnFechar.Click += btnFechar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(596, 527);
            Controls.Add(btnFechar);
            Controls.Add(btnLimpar);
            Controls.Add(btnCalcular);
            Controls.Add(txtVolume);
            Controls.Add(lblVolume);
            Controls.Add(txtAltura);
            Controls.Add(lblAltura);
            Controls.Add(txtRaio);
            Controls.Add(lblRaio);
            Name = "Form1";
            Text = "Calcular Volume do Cilindro";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblRaio;
        private TextBox txtRaio;
        private TextBox txtAltura;
        private Label lblAltura;
        private TextBox txtVolume;
        private Label lblVolume;
        private Button btnCalcular;
        private Button btnLimpar;
        private Button btnFechar;
    }
}
