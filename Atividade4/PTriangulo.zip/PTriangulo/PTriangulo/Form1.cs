namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double lado1, lado2, lado3;
        public Form1()
        {
            InitializeComponent();
        }


        private void txtL1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtL1.Text, out lado1))
            {
                errorL1.SetError(txtL1, "Informe um n�mero v�lido!");
                txtL1.Focus();
            }
            else
            {
                errorL1.Clear();
            }
        }

        private void txtL2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtL2.Text, out lado2))
            {
                errorL2.SetError(txtL2, "Informe um n�mero v�lido!");
                txtL2.Focus();
            }
            else
            {
                errorL2.Clear();
            }
        }

        private void txtL3_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtL3.Text, out lado3))
            {
                errorL3.SetError(txtL3, "Informe um n�mero v�lido!");
                txtL3.Focus();
            }
            else
            {
                errorL3.Clear();
            }
        }

        private void btnValidar_Click(object sender, EventArgs e)
        {
            if (lado1 < lado2 + lado3 &&
                lado1 > Math.Abs(lado2 - lado3) &&
                lado2 < lado1 + lado3 &&
                lado2 > Math.Abs(lado1 - lado3) &&
                lado3 < lado1 + lado2 &&
                lado3 > Math.Abs(lado1 - lado2)
                )
            {
                if (lado1 == lado2 && lado2 == lado3)
                {
                    lblResultado.Visible = true;
                    lblResultado.Text = "Tri�ngulo equil�tero!";
                }
                else if (lado1 == lado2 || lado2 == lado3 || lado3 == lado1)
                {
                    lblResultado.Visible = true;
                    lblResultado.Text = "Tri�ngulo is�sceles!";
                }
                else
                {
                    lblResultado.Visible = true;
                    lblResultado.Text = "Tri�ngulo escaleno!";
                }
            }
            else
            {
                lblResultado.Visible = true;
                lblResultado.Text = "N�o � um tri�ngulo!";
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtL1.Clear();
            txtL2.Clear();
            txtL3.Clear();
            lblResultado.Visible = false;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
