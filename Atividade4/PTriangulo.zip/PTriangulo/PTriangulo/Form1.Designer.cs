﻿namespace PTriangulo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            lblL1 = new Label();
            txtL1 = new TextBox();
            txtL2 = new TextBox();
            lblL2 = new Label();
            txtL3 = new TextBox();
            lblL3 = new Label();
            btnSair = new Button();
            errorL1 = new ErrorProvider(components);
            errorL2 = new ErrorProvider(components);
            errorL3 = new ErrorProvider(components);
            btnLimpar = new Button();
            btnValidar = new Button();
            lblResultado = new Label();
            ((System.ComponentModel.ISupportInitialize)errorL1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorL2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorL3).BeginInit();
            SuspendLayout();
            // 
            // lblL1
            // 
            lblL1.AutoSize = true;
            lblL1.Location = new Point(69, 50);
            lblL1.Name = "lblL1";
            lblL1.Size = new Size(70, 25);
            lblL1.TabIndex = 0;
            lblL1.Text = "Lado 1:";
            // 
            // txtL1
            // 
            txtL1.Location = new Point(140, 47);
            txtL1.Name = "txtL1";
            txtL1.Size = new Size(150, 31);
            txtL1.TabIndex = 1;
            txtL1.Validated += txtL1_Validated;
            // 
            // txtL2
            // 
            txtL2.Location = new Point(140, 84);
            txtL2.Name = "txtL2";
            txtL2.Size = new Size(150, 31);
            txtL2.TabIndex = 3;
            txtL2.Validated += txtL2_Validated;
            // 
            // lblL2
            // 
            lblL2.AutoSize = true;
            lblL2.Location = new Point(69, 87);
            lblL2.Name = "lblL2";
            lblL2.Size = new Size(70, 25);
            lblL2.TabIndex = 2;
            lblL2.Text = "Lado 2:";
            // 
            // txtL3
            // 
            txtL3.Location = new Point(140, 121);
            txtL3.Name = "txtL3";
            txtL3.Size = new Size(150, 31);
            txtL3.TabIndex = 5;
            txtL3.Validated += txtL2_Validated;
            // 
            // lblL3
            // 
            lblL3.AutoSize = true;
            lblL3.Location = new Point(69, 124);
            lblL3.Name = "lblL3";
            lblL3.Size = new Size(70, 25);
            lblL3.TabIndex = 4;
            lblL3.Text = "Lado 3:";
            // 
            // btnSair
            // 
            btnSair.Location = new Point(255, 243);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(112, 34);
            btnSair.TabIndex = 8;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // errorL1
            // 
            errorL1.ContainerControl = this;
            // 
            // errorL2
            // 
            errorL2.ContainerControl = this;
            // 
            // errorL3
            // 
            errorL3.ContainerControl = this;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(137, 243);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(112, 34);
            btnLimpar.TabIndex = 9;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnValidar
            // 
            btnValidar.Location = new Point(19, 243);
            btnValidar.Name = "btnValidar";
            btnValidar.Size = new Size(112, 34);
            btnValidar.TabIndex = 10;
            btnValidar.Text = "Validar";
            btnValidar.UseVisualStyleBackColor = true;
            btnValidar.Click += btnValidar_Click;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(19, 189);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(59, 25);
            lblResultado.TabIndex = 11;
            lblResultado.Text = "label1";
            lblResultado.Visible = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(386, 304);
            Controls.Add(lblResultado);
            Controls.Add(btnValidar);
            Controls.Add(btnLimpar);
            Controls.Add(btnSair);
            Controls.Add(txtL3);
            Controls.Add(lblL3);
            Controls.Add(txtL2);
            Controls.Add(lblL2);
            Controls.Add(txtL1);
            Controls.Add(lblL1);
            Name = "Form1";
            Text = "Testador de Triângulos";
            ((System.ComponentModel.ISupportInitialize)errorL1).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorL2).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorL3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblL1;
        private TextBox txtL1;
        private TextBox txtL2;
        private Label lblL2;
        private TextBox txtL3;
        private Label lblL3;
        private Button button1;
        private Button button2;
        private Button btnSair;
        private ErrorProvider errorL1;
        private ErrorProvider errorL2;
        private ErrorProvider errorL3;
        private Button btnValidar;
        private Button btnLimpar;
        private Label lblResultado;
    }
}
