﻿namespace PCalc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            lblNum1 = new Label();
            txtNum1 = new TextBox();
            txtNum2 = new TextBox();
            lblNum2 = new Label();
            txtResult = new TextBox();
            lblResult = new Label();
            btnLimpar = new Button();
            BtnSair = new Button();
            btnAdd = new Button();
            btnSub = new Button();
            btnMult = new Button();
            btnDiv = new Button();
            errorProvider1 = new ErrorProvider(components);
            errorProvider2 = new ErrorProvider(components);
            errorProvider3 = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider3).BeginInit();
            SuspendLayout();
            // 
            // lblNum1
            // 
            lblNum1.AutoSize = true;
            lblNum1.Location = new Point(53, 34);
            lblNum1.Name = "lblNum1";
            lblNum1.Size = new Size(96, 25);
            lblNum1.TabIndex = 0;
            lblNum1.Text = "Número 1:";
            // 
            // txtNum1
            // 
            txtNum1.Location = new Point(155, 31);
            txtNum1.Name = "txtNum1";
            txtNum1.Size = new Size(150, 31);
            txtNum1.TabIndex = 1;
            txtNum1.Validated += txtNum1_Validated;
            // 
            // txtNum2
            // 
            txtNum2.Location = new Point(155, 78);
            txtNum2.Name = "txtNum2";
            txtNum2.Size = new Size(150, 31);
            txtNum2.TabIndex = 3;
            txtNum2.Validated += txtNum2_Validated;
            // 
            // lblNum2
            // 
            lblNum2.AutoSize = true;
            lblNum2.Location = new Point(53, 81);
            lblNum2.Name = "lblNum2";
            lblNum2.Size = new Size(96, 25);
            lblNum2.TabIndex = 2;
            lblNum2.Text = "Número 2:";
            // 
            // txtResult
            // 
            txtResult.Enabled = false;
            txtResult.Location = new Point(155, 154);
            txtResult.Name = "txtResult";
            txtResult.Size = new Size(150, 31);
            txtResult.TabIndex = 5;
            // 
            // lblResult
            // 
            lblResult.AutoSize = true;
            lblResult.Location = new Point(53, 157);
            lblResult.Name = "lblResult";
            lblResult.Size = new Size(94, 25);
            lblResult.TabIndex = 4;
            lblResult.Text = "Resultado:";
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(336, 29);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(112, 34);
            btnLimpar.TabIndex = 6;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // BtnSair
            // 
            BtnSair.Location = new Point(336, 76);
            BtnSair.Name = "BtnSair";
            BtnSair.Size = new Size(112, 34);
            BtnSair.TabIndex = 7;
            BtnSair.Text = "Sair";
            BtnSair.UseVisualStyleBackColor = true;
            BtnSair.Click += BtnSair_Click;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(74, 196);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(73, 34);
            btnAdd.TabIndex = 8;
            btnAdd.Text = "+";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnSub
            // 
            btnSub.Location = new Point(154, 196);
            btnSub.Name = "btnSub";
            btnSub.Size = new Size(73, 34);
            btnSub.TabIndex = 12;
            btnSub.Text = "-";
            btnSub.UseVisualStyleBackColor = true;
            btnSub.Click += btnSub_Click;
            // 
            // btnMult
            // 
            btnMult.Location = new Point(233, 196);
            btnMult.Name = "btnMult";
            btnMult.Size = new Size(73, 34);
            btnMult.TabIndex = 13;
            btnMult.Text = "*";
            btnMult.UseVisualStyleBackColor = true;
            btnMult.Click += btnMult_Click;
            // 
            // btnDiv
            // 
            btnDiv.Location = new Point(312, 196);
            btnDiv.Name = "btnDiv";
            btnDiv.Size = new Size(73, 34);
            btnDiv.TabIndex = 14;
            btnDiv.Text = "/";
            btnDiv.UseVisualStyleBackColor = true;
            btnDiv.Click += btnDiv_Click;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            errorProvider3.ContainerControl = this;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(470, 273);
            Controls.Add(btnDiv);
            Controls.Add(btnMult);
            Controls.Add(btnSub);
            Controls.Add(btnAdd);
            Controls.Add(BtnSair);
            Controls.Add(btnLimpar);
            Controls.Add(txtResult);
            Controls.Add(lblResult);
            Controls.Add(txtNum2);
            Controls.Add(lblNum2);
            Controls.Add(txtNum1);
            Controls.Add(lblNum1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNum1;
        private TextBox txtNum1;
        private TextBox txtNum2;
        private Label lblNum2;
        private TextBox txtResult;
        private Label lblResult;
        private Button btnLimpar;
        private Button BtnSair;
        private Button btnAdd;
        private Button btnSub;
        private Button btnMult;
        private Button btnDiv;
        private ErrorProvider errorProvider1;
        private ErrorProvider errorProvider2;
        private ErrorProvider errorProvider3;
    }
}
