namespace PCalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum1.Text, out numero1))
            {
                errorProvider1.SetError(txtNum1, "N�mero 1 inv�lido!");
                txtNum1.Focus();
            }
            else
                errorProvider1.SetError(txtNum1, "");
        }

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(txtNum2, "");
                numero2 = Convert.ToDouble(txtNum2.Text);
            }
            catch
            {
                errorProvider2.SetError(txtNum2, "N�mero 2 inv�lido!");
                txtNum2.Focus();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResult.Text = resultado.ToString();
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResult.Text = resultado.ToString();
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResult.Text = resultado.ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                errorProvider3.SetError(btnDiv, "O 2� n�mero n�o pode ser 0!");
            }

            resultado = numero1 / numero2;
            txtResult.Text = resultado.ToString();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Text = "";
            txtNum2.Text = "";
            txtResult.Text = "";
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
